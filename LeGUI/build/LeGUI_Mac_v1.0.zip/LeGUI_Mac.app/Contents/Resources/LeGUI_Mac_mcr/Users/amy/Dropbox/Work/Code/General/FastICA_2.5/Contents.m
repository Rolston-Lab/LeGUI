% FastICA for Matlab 7.x and 6.x
% Version 2.5, October 19 2005

% ArduinoIO (a.k.a  "Tethered" MATLAB Support Package for Arduino)
% Version 4.4 (R2013a), G. Campa,  30-Aug-2013

% EEGLAB Toolbox to process EEG data
% Version - see eeg_getversion()
